using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    public bool[] isFull;
    public GameObject[] slots;
    // public int stars;

    // public void CheckFull()
    // {
    //     Debug.Log(isFull[0]);
    //     Debug.Log(isFull[1]);
    //     Debug.Log(isFull[2]);
    // }
}
